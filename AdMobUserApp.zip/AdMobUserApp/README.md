# AdMob User App

A minimal Android (Kotlin) app that shows:
- A **banner ad**
- An **interstitial (video) ad**
- A **rewarded video ad**

...all loaded using **Ad Unit IDs the user enters themselves** in the Settings screen,
so the ad revenue is attributed to whichever AdMob account those IDs belong to.

## How it works

- `SettingsActivity` lets the user paste in their own Banner / Interstitial / Rewarded
  **Ad Unit IDs** and saves them to on-device `SharedPreferences` (see `AdPrefs.kt`).
- `MainActivity` reads those saved IDs and uses them when loading each ad. If nothing
  has been entered yet, it falls back to Google's public **test ad unit IDs** so the
  app still runs out of the box.
- Watching a rewarded ad credits in-app "coins" — you can replace that with your own
  reward logic (unlocking content, currency, etc.).

## Important: App ID vs. Ad Unit ID

AdMob has two different kinds of IDs:

1. **App ID** (`ca-app-pub-xxxx~xxxx`) — declared in `AndroidManifest.xml`, required to
   initialize the Mobile Ads SDK. This is fixed at build time and belongs to whoever
   compiles/publishes the APK. It currently contains **Google's public test App ID** —
   replace it with your own before publishing.
2. **Ad Unit ID** (`ca-app-pub-xxxx/xxxx`) — this is what actually determines who gets
   paid for an impression, and it's the one this app lets each user configure at
   runtime. This is the mechanism that makes "ads pay into the user's own AdMob
   account" possible without rebuilding the app per user.

## Before you publish this

- **AdMob policy**: Google restricts how ad placements and traffic sources can be used,
  and templated apps that let arbitrary third parties plug in their own ad unit IDs to
  monetize the same install base are something Google actively monitors for invalid
  traffic / policy violations. If you're distributing this to multiple people rather
  than using it yourself, review [AdMob policies](https://support.google.com/admob/answer/6128543)
  before publishing, since accounts can be suspended for violations.
- Swap the manifest App ID for your real one.
- Do basic input validation on the Ad Unit ID fields (this starter doesn't validate format).

## How to build

1. Install [Android Studio](https://developer.android.com/studio).
2. Open this folder as a project (`File > Open`).
3. Let Gradle sync (it will download the AdMob SDK automatically).
4. Run on an emulator or device (`Run > Run 'app'`).
5. On first launch, tap **Configure My AdMob IDs** and paste in your own Ad Unit IDs
   from the [AdMob console](https://apps.admob.com/).

## Project structure

```
app/src/main/java/com/example/admobuserapp/
  MainActivity.kt       - shows banner/interstitial/rewarded ads
  SettingsActivity.kt    - lets the user enter their own Ad Unit IDs
  AdPrefs.kt              - SharedPreferences storage for those IDs
app/src/main/res/layout/
  activity_main.xml
  activity_settings.xml
app/src/main/AndroidManifest.xml
```
