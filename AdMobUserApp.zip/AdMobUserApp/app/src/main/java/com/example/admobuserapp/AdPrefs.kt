package com.example.admobuserapp

import android.content.Context

/**
 * Stores the ad unit IDs entered by the user on this device.
 * Whichever IDs are saved here are the ones ads will load with,
 * so ad revenue is attributed to whoever owns those IDs.
 */
object AdPrefs {
    private const val PREFS_NAME = "ad_unit_prefs"
    private const val KEY_BANNER = "banner_id"
    private const val KEY_INTERSTITIAL = "interstitial_id"
    private const val KEY_REWARDED = "rewarded_id"

    // Google's public test ad unit IDs - safe fallbacks so the app
    // still shows (test) ads before the user configures their own.
    const val TEST_BANNER = "ca-app-pub-3940256099942544/9214589741"
    const val TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveIds(context: Context, banner: String, interstitial: String, rewarded: String) {
        prefs(context).edit()
            .putString(KEY_BANNER, banner)
            .putString(KEY_INTERSTITIAL, interstitial)
            .putString(KEY_REWARDED, rewarded)
            .apply()
    }

    fun getBannerId(context: Context): String =
        prefs(context).getString(KEY_BANNER, null)?.takeIf { it.isNotBlank() } ?: TEST_BANNER

    fun getInterstitialId(context: Context): String =
        prefs(context).getString(KEY_INTERSTITIAL, null)?.takeIf { it.isNotBlank() } ?: TEST_INTERSTITIAL

    fun getRewardedId(context: Context): String =
        prefs(context).getString(KEY_REWARDED, null)?.takeIf { it.isNotBlank() } ?: TEST_REWARDED

    fun rawBanner(context: Context): String = prefs(context).getString(KEY_BANNER, "") ?: ""
    fun rawInterstitial(context: Context): String = prefs(context).getString(KEY_INTERSTITIAL, "") ?: ""
    fun rawRewarded(context: Context): String = prefs(context).getString(KEY_REWARDED, "") ?: ""
}
