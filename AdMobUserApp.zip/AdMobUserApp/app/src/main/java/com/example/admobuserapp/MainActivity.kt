package com.example.admobuserapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : AppCompatActivity() {

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var coins = 0

    private lateinit var txtCoins: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtCoins = findViewById(R.id.txtCoins)
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.btnShowInterstitial).setOnClickListener { showInterstitial() }
        findViewById<Button>(R.id.btnShowRewarded).setOnClickListener { showRewarded() }

        // Initialize the Mobile Ads SDK once per app launch
        MobileAds.initialize(this) {
            loadBanner()
            loadInterstitial()
            loadRewarded()
        }
    }

    override fun onResume() {
        super.onResume()
        // Ad unit IDs may have changed in Settings, so refresh interstitial/rewarded
        // (banner reloads automatically below if the container is empty)
        if (findViewById<FrameLayout>(R.id.bannerContainer).childCount == 0) {
            loadBanner()
        }
    }

    private fun loadBanner() {
        val container = findViewById<FrameLayout>(R.id.bannerContainer)
        container.removeAllViews()

        val adView = AdView(this)
        adView.adUnitId = AdPrefs.getBannerId(this)
        adView.setAdSize(AdSize.BANNER)
        container.addView(adView)
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            AdPrefs.getInterstitialId(this),
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun showInterstitial() {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial() // preload the next one
                }
            }
            ad.show(this)
        } else {
            Toast.makeText(this, "Ad not ready yet, try again shortly", Toast.LENGTH_SHORT).show()
            loadInterstitial()
        }
    }

    private fun loadRewarded() {
        RewardedAd.load(
            this,
            AdPrefs.getRewardedId(this),
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    private fun showRewarded() {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded() // preload the next one
                }
            }
            ad.show(this) { rewardItem ->
                // This fires only if the user actually earned the reward.
                // Because the ad unit ID itself belongs to the user configured
                // in Settings, the AdMob impression/earnings are already
                // attributed to that user's AdMob account server-side.
                coins += rewardItem.amount
                txtCoins.text = "Coins: $coins"
                Toast.makeText(this, "You earned ${rewardItem.amount} ${rewardItem.type}!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Ad not ready yet, try again shortly", Toast.LENGTH_SHORT).show()
            loadRewarded()
        }
    }
}
