package com.example.admobuserapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val editBanner = findViewById<EditText>(R.id.editBannerId)
        val editInterstitial = findViewById<EditText>(R.id.editInterstitialId)
        val editRewarded = findViewById<EditText>(R.id.editRewardedId)
        val btnSave = findViewById<Button>(R.id.btnSave)

        // Pre-fill with whatever is already saved
        editBanner.setText(AdPrefs.rawBanner(this))
        editInterstitial.setText(AdPrefs.rawInterstitial(this))
        editRewarded.setText(AdPrefs.rawRewarded(this))

        btnSave.setOnClickListener {
            AdPrefs.saveIds(
                this,
                editBanner.text.toString().trim(),
                editInterstitial.text.toString().trim(),
                editRewarded.text.toString().trim()
            )
            Toast.makeText(this, "Ad Unit IDs saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
